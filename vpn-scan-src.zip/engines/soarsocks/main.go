// soarsocks: یک پروکسی SOCKS5 محلی روی تونل DNS «Soar» (github.com/getlantern/soar، Apache-2.0).
// بخشی از VPN Scan؛ به شکل libsoar.so در اپ قرار می‌گیرد و با یک فایل JSON اجرا می‌شود.
package main

import (
	"context"
	"crypto/ed25519"
	"encoding/base64"
	"encoding/binary"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"log/slog"
	"net"
	"os"
	"os/signal"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"

	"github.com/getlantern/soar"
)

type conf struct {
	Domain    string   `json:"domain"`
	PublicKey string   `json:"public_key"`
	Resolvers []string `json:"resolvers"`
	// resolverهای پیشنهادی برنامه: اول وارسی می‌شوند و فقط اگر واقعاً تونل را رساندند استفاده می‌شوند
	Candidates []string `json:"candidates"`
	// فایل نگه‌داری resolverهای وارسی‌شده (اتصال بعدی سریع‌تر)
	Cache  string `json:"cache"`
	Listen string `json:"listen"`
	S         struct {
		Transport            string `json:"transport"`
		Discovery            *bool  `json:"discovery"`
		DiscoveryWant        int    `json:"discoveryWant"`
		DiscoveryConcurrency int    `json:"discoveryConcurrency"`
		DiscoveryPaceMs      int    `json:"discoveryPaceMs"`
		SafeQName            int    `json:"safeQName"`
		MaxQName             int    `json:"maxQName"`
		MaxAnswer            int    `json:"maxAnswer"`
		HoldMs               int    `json:"holdMs"`
		MaxInflight          int    `json:"maxInflight"`
		MaxPathWindow        int    `json:"maxPathWindow"`
		MaxStreams           int    `json:"maxStreams"`
		StreamWindowKiB      int    `json:"streamWindowKiB"`
		SendBufferKiB        int    `json:"sendBufferKiB"`
		SessionIdleSeconds   int    `json:"sessionIdleSeconds"`
		DialTimeoutSeconds   int    `json:"dialTimeoutSeconds"`
		Country              string `json:"country"`
	} `json:"soarSettings"`
}

func decodeKey(s string) (ed25519.PublicKey, error) {
	s = strings.TrimSpace(s)
	for _, enc := range []*base64.Encoding{base64.StdEncoding, base64.RawStdEncoding, base64.URLEncoding, base64.RawURLEncoding} {
		if b, err := enc.DecodeString(s); err == nil && len(b) == ed25519.PublicKeySize {
			return ed25519.PublicKey(b), nil
		}
	}
	return nil, errors.New("bad public_key (want base64 ed25519)")
}

func withPort(r string) string {
	r = strings.TrimSpace(r)
	if r == "" {
		return ""
	}
	if _, _, err := net.SplitHostPort(r); err == nil {
		return r
	}
	return net.JoinHostPort(r, "53")
}

// fileCache: resolverهای تأییدشده در یک فایل متنی
type fileCache string

func (f fileCache) Load() []string {
	b, err := os.ReadFile(string(f))
	if err != nil {
		return nil
	}
	var out []string
	for _, l := range strings.Split(string(b), "\n") {
		if l = strings.TrimSpace(l); l != "" {
			out = append(out, l)
		}
	}
	return out
}

func (f fileCache) Store(r []string) { _ = os.WriteFile(string(f), []byte(strings.Join(r, "\n")), 0o600) }

func main() {
	cfgPath := flag.String("c", "", "config JSON")
	flag.Parse()
	raw, err := os.ReadFile(*cfgPath)
	if err != nil {
		fmt.Println("config:", err)
		os.Exit(2)
	}
	var c conf
	if err := json.Unmarshal(raw, &c); err != nil {
		fmt.Println("config:", err)
		os.Exit(2)
	}
	key, err := decodeKey(c.PublicKey)
	if err != nil {
		fmt.Println(err)
		os.Exit(2)
	}
	var res []string
	for _, r := range c.Resolvers {
		if w := withPort(r); w != "" {
			res = append(res, w)
		}
	}
	sc := soar.Config{
		Zone:          strings.TrimSuffix(strings.TrimSpace(c.Domain), "."),
		ServerKey:     key,
		Resolvers:     res,
		SafeQName:     c.S.SafeQName,
		MaxQName:      c.S.MaxQName,
		MaxAnswer:     c.S.MaxAnswer,
		MaxInflight:   c.S.MaxInflight,
		MaxPathWindow: c.S.MaxPathWindow,
		MaxStreams:    c.S.MaxStreams,
		TCP:           c.S.Transport,
		Logger:        slog.New(slog.NewTextHandler(os.Stdout, &slog.HandlerOptions{Level: slog.LevelWarn})),
	}
	if c.S.HoldMs > 0 {
		sc.Hold = time.Duration(c.S.HoldMs) * time.Millisecond
	}
	if c.S.StreamWindowKiB > 0 {
		sc.StreamWindow = uint64(c.S.StreamWindowKiB) << 10
	}
	if c.S.SendBufferKiB > 0 {
		sc.SendBuffer = c.S.SendBufferKiB << 10
	}
	if c.S.SessionIdleSeconds > 0 {
		sc.SessionIdle = time.Duration(c.S.SessionIdleSeconds) * time.Second
	}
	if sc.TCP == "" {
		sc.TCP = "auto"
	}
	var cands []string
	for _, r := range c.Candidates {
		if w := withPort(r); w != "" {
			cands = append(cands, w)
		}
	}
	disc := c.S.Discovery == nil || *c.S.Discovery
	if disc || len(res) == 0 || len(cands) > 0 {
		sc.Discovery = soar.Discovery{Enabled: true, Country: strings.ToUpper(c.S.Country), Want: c.S.DiscoveryWant, Concurrency: c.S.DiscoveryConcurrency, Candidates: cands}
		if c.Cache != "" {
			sc.Discovery.Cache = fileCache(c.Cache)
		}
		if sc.Discovery.Country == "" {
			sc.Discovery.Country = "IR"
		}
		if c.S.DiscoveryPaceMs > 0 {
			sc.Discovery.Pace = time.Duration(c.S.DiscoveryPaceMs) * time.Millisecond
		}
	}
	cl, err := soar.NewClient(sc)
	if err != nil {
		fmt.Println("soar:", err)
		os.Exit(1)
	}
	defer cl.Close()
	dialTO := time.Duration(c.S.DialTimeoutSeconds) * time.Second
	if dialTO <= 0 {
		dialTO = 90 * time.Second
	}
	listen := c.Listen
	if listen == "" {
		listen = "127.0.0.1:18080"
	}
	ln, err := net.Listen("tcp", listen)
	if err != nil {
		fmt.Println("listen:", err)
		os.Exit(1)
	}
	fmt.Println("SOCKS5 listening on", ln.Addr())
	go func() {
		ch := make(chan os.Signal, 1)
		signal.Notify(ch, syscall.SIGINT, syscall.SIGTERM)
		<-ch
		ln.Close()
	}()
	for {
		conn, err := ln.Accept()
		if err != nil {
			return
		}
		go handle(conn, cl, dialTO)
	}
}

// SOCKS5 بدون رمز، فقط CONNECT (برای TCP؛ Soar فقط TCP منتقل می‌کند)
func handle(conn net.Conn, cl *soar.Client, dialTO time.Duration) {
	defer conn.Close()
	_ = conn.SetDeadline(time.Now().Add(30 * time.Second))
	b := make([]byte, 262)
	if _, err := io.ReadFull(conn, b[:2]); err != nil || b[0] != 5 {
		return
	}
	if _, err := io.ReadFull(conn, b[:int(b[1])]); err != nil {
		return
	}
	conn.Write([]byte{5, 0})
	if _, err := io.ReadFull(conn, b[:4]); err != nil || b[1] != 1 {
		conn.Write([]byte{5, 7, 0, 1, 0, 0, 0, 0, 0, 0})
		return
	}
	var host string
	switch b[3] {
	case 1:
		io.ReadFull(conn, b[:4])
		host = net.IP(b[:4]).String()
	case 3:
		io.ReadFull(conn, b[:1])
		n := int(b[0])
		io.ReadFull(conn, b[:n])
		host = string(b[:n])
	case 4:
		io.ReadFull(conn, b[:16])
		host = net.IP(b[:16]).String()
	default:
		return
	}
	io.ReadFull(conn, b[:2])
	port := binary.BigEndian.Uint16(b[:2])
	ctx, cancel := context.WithTimeout(context.Background(), dialTO)
	up, err := cl.DialContext(ctx, "tcp", net.JoinHostPort(host, strconv.Itoa(int(port))))
	cancel()
	if err != nil {
		conn.Write([]byte{5, 5, 0, 1, 0, 0, 0, 0, 0, 0})
		return
	}
	defer up.Close()
	conn.Write([]byte{5, 0, 0, 1, 0, 0, 0, 0, 0, 0})
	_ = conn.SetDeadline(time.Time{})
	var wg sync.WaitGroup
	wg.Add(2)
	go func() { io.Copy(up, conn); closeWrite(up); wg.Done() }()
	go func() { io.Copy(conn, up); closeWrite(conn); wg.Done() }()
	wg.Wait()
}

func closeWrite(c net.Conn) {
	if cw, ok := c.(interface{ CloseWrite() error }); ok {
		cw.CloseWrite()
	} else {
		c.Close()
	}
}
