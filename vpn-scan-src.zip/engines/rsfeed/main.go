// rsfeed: خواندن پیام‌های کانال‌های یک سرور thefeed از راه DNS و چاپ JSON — بخشی از VPN Scan.
// موقع ساخت داخل ماژول thefeed (github.com/sartoopjj/thefeed، MIT) در cmd/rsfeed کپی می‌شود.
package main

import (
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"net"
	"os"
	"strings"
	"sync"
	"time"

	"github.com/sartoopjj/thefeed/internal/client"
)

type conf struct {
	Domain    string   `json:"domain"`
	Key       string   `json:"key"`
	SK        string   `json:"sk"`
	Extra     []string `json:"extra"`
	Resolvers []string `json:"resolvers"`
	MaxChan   int      `json:"maxChannels"`
	Timeout   int      `json:"timeoutSec"`
}

type chOut struct {
	Name  string   `json:"name"`
	Title string   `json:"title"`
	Msgs  []string `json:"msgs"`
	Err   string   `json:"err,omitempty"`
}

func out(v any) { b, _ := json.Marshal(v); fmt.Println(string(b)) }

func main() {
	cfgPath := flag.String("c", "", "config JSON")
	verbose := flag.Bool("v", false, "log to stderr")
	flag.Parse()
	raw, err := os.ReadFile(*cfgPath)
	if err != nil {
		out(map[string]any{"ok": false, "err": err.Error()})
		return
	}
	var c conf
	if err := json.Unmarshal(raw, &c); err != nil {
		out(map[string]any{"ok": false, "err": err.Error()})
		return
	}
	var res []string
	for _, r := range c.Resolvers {
		r = strings.TrimSpace(r)
		if r == "" {
			continue
		}
		if _, _, e := net.SplitHostPort(r); e != nil {
			r = net.JoinHostPort(r, "53")
		}
		res = append(res, r)
	}
	if c.Timeout <= 0 {
		c.Timeout = 120
	}
	if c.MaxChan <= 0 {
		c.MaxChan = 500
	}
	ctx, cancel := context.WithTimeout(context.Background(), time.Duration(c.Timeout)*time.Second)
	defer cancel()

	f, err := client.NewFetcher(c.Domain, c.Key, res)
	if err != nil {
		out(map[string]any{"ok": false, "err": err.Error()})
		return
	}
	if len(c.Extra) > 0 {
		f.SetDomains(c.Extra)
	}
	if c.SK != "" {
		_ = f.SetServerPublicKey(c.SK)
	}
	f.SetActiveResolvers(res)
	if *verbose {
		f.SetLogFunc(func(m string) { fmt.Fprintln(os.Stderr, m) })
		f.SetDebug(true)
	}
	f.SetTimeout(12 * time.Second)
	f.SetScatter(4)
	f.SetNoiseDisabled(true)
	f.Start(ctx)

	meta, err := f.FetchMetadata(ctx)
	if err != nil {
		out(map[string]any{"ok": false, "err": "metadata: " + err.Error()})
		return
	}
	// همهٔ کانال‌ها، سه‌تا هم‌زمان؛ ترتیب کانال‌ها حفظ می‌شود
	n := len(meta.Channels)
	if n > c.MaxChan {
		n = c.MaxChan
	}
	chans := make([]chOut, n)
	jobs := make(chan int)
	var wg sync.WaitGroup
	for w := 0; w < 3; w++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for i := range jobs {
				ch := meta.Channels[i]
				o := chOut{Name: ch.Name, Title: ch.DisplayName, Msgs: []string{}}
				if ctx.Err() != nil {
					o.Err = "timeout"
					chans[i] = o
					continue
				}
				if int(ch.Blocks) > 0 {
					got, err := f.FetchChannelVerified(ctx, i+1, int(ch.Blocks), ch.ContentHash)
					if err != nil && ctx.Err() == nil {
						got, err = f.FetchChannel(ctx, i+1, int(ch.Blocks))
					}
					if err != nil {
						o.Err = err.Error()
					}
					for _, m := range got {
						o.Msgs = append(o.Msgs, m.Text)
					}
				}
				chans[i] = o
			}
		}()
	}
	for i := 0; i < n; i++ {
		jobs <- i
	}
	close(jobs)
	wg.Wait()
	out(map[string]any{"ok": true, "channels": chans})
}
