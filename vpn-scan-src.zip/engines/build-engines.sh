#!/usr/bin/env bash
# ساخت موتورهای تونل DNS برای اندروید (arm64) از سورس اصلی هر پروژه، با commit ثابت.
#   MasterDnsVPN (MIT)  github.com/masterking32/MasterDnsVPN   → libmdns.so
#   StormDNS     (MIT)  github.com/NullRoute1970/StormDNS      → libstorm.so
#   CottenDNS    (MIT)  github.com/WhiteDNS/CottenDNS          → libcotten.so
#   Soar   (Apache-2.0) github.com/getlantern/soar  + soarsocks (همین پوشه) → libsoar.so
#   thefeed      (MIT)  github.com/sartoopjj/thefeed + rsfeed (همین پوشه)   → libfeed.so
# اگر Go نصب نباشد یا ساخت یکی نشد، برنامه بدون همان موتور ساخته می‌شود.
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="${1:-$HERE/../app/src/main/jniLibs/arm64-v8a}"
mkdir -p "$OUT"
command -v go >/dev/null 2>&1 || { echo "engines: Go not found → skipped"; exit 0; }
export CGO_ENABLED=0 GOOS=linux GOARCH=arm64 GOTOOLCHAIN=auto GOFLAGS=-trimpath
W="$(mktemp -d)"
build() {   # repo commit pkg out
  local repo=$1 sha=$2 pkg=$3 out=$4
  [ -f "$OUT/$out" ] && { echo "engines: $out exists"; return 0; }
  local d="$W/$(basename "$repo")"
  if git clone -q "https://github.com/$repo" "$d" && git -C "$d" checkout -q "$sha"; then
    if (cd "$d" && go build -ldflags "-s -w" -o "$OUT/$out" "$pkg"); then echo "engines: built $out"; else echo "engines: FAILED $out"; rm -f "$OUT/$out"; fi
  else echo "engines: clone failed $repo"; fi
}
build masterking32/MasterDnsVPN 5f83ee9a1690a968f9edf495d3a7e00a2043b0bd ./cmd/client libmdns.so
build NullRoute1970/StormDNS    a9a8e92a51f08c3030d7a1656cafd3bf07c9903b ./cmd/client libstorm.so
build WhiteDNS/CottenDNS        7db7b73658c791cce62300d29647e4d369d6e1e4 ./cmd/client libcotten.so
if [ ! -f "$OUT/libsoar.so" ]; then
  (cd "$HERE/soarsocks" && go mod tidy >/dev/null 2>&1; go build -ldflags "-s -w" -o "$OUT/libsoar.so" .) && echo "engines: built libsoar.so" || { echo "engines: FAILED libsoar.so"; rm -f "$OUT/libsoar.so"; }
fi
if [ ! -f "$OUT/libfeed.so" ]; then
  d="$W/thefeed"
  if git clone -q https://github.com/sartoopjj/thefeed "$d" && git -C "$d" checkout -q 12512431da9600ff4f6a0d1bbfe6c6219fdea86d; then
    mkdir -p "$d/cmd/rsfeed" && cp "$HERE/rsfeed/main.go" "$d/cmd/rsfeed/main.go"
    (cd "$d" && go build -ldflags "-s -w" -o "$OUT/libfeed.so" ./cmd/rsfeed) && echo "engines: built libfeed.so" || { echo "engines: FAILED libfeed.so"; rm -f "$OUT/libfeed.so"; }
  else echo "engines: clone failed thefeed"; fi
fi
rm -rf "$W"
ls -la "$OUT"
exit 0
