# موتورهای تونل DNS / DNS tunnel engines

این موتورها از سورس اصلی خودشان ساخته می‌شوند و مجوزشان حفظ شده است:

| موتور | پروژه | مجوز |
|---|---|---|
| MasterDNS | github.com/masterking32/MasterDnsVPN — Amin Mahmoudi | MIT |
| StormDNS | github.com/NullRoute1970/StormDNS — NullRoute1970 | MIT |
| CottenDNS | github.com/WhiteDNS/CottenDNS — tajirax | MIT |
| Soar | github.com/getlantern/soar — Lantern | Apache-2.0 |
| thefeed | github.com/sartoopjj/thefeed — sartoopjj | MIT |

`soarsocks/` یک پروکسی SOCKS5 کوچک روی کتابخانهٔ Soar است که برای همین برنامه نوشته شده.

`rsfeed/` برنامهٔ کوچکی است که با کتابخانهٔ کلاینت thefeed پیام‌های کانال‌ها را از راه DNS می‌خواند (موقع ساخت داخل ماژول thefeed کپی می‌شود).

## jsQR (assets/jsqr.js)
QR decoding of images received through thefeed. https://github.com/cozmo/jsQR — Apache License 2.0, Copyright 2017 Cosmo Wolfe.
