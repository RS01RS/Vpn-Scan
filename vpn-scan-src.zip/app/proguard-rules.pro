# ===== VPN Scan — قوانین مبهم‌سازی (R8) =====
# هدف: کد جاوا نامفهوم شود، ولی چیزهایی که از بیرون (WebView، اندروید، JNI) با نام صدا زده می‌شوند سالم بمانند.

# پل WebView: متدهای @JavascriptInterface با نام از جاوااسکریپت صدا زده می‌شوند؛ نباید rename شوند.
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# کلاس‌هایی که در AndroidManifest اعلام شده‌اند (Activity, Service, Provider, Tile) نقطهٔ ورودند و نباید حذف/تغییرنام شوند.
-keep class com.rs.v2ray.MainActivity { *; }
-keep class com.rs.v2ray.RsVpnService { *; }
-keep class com.rs.v2ray.RsFiles { *; }
-keep class com.rs.v2ray.RsTileService { *; }

# BuildConfig (PLAY و شماره‌های نسخه) با نام خوانده می‌شود.
-keep class com.rs.v2ray.BuildConfig { *; }

# متدهای native و enumها
-keepclasseswithmembernames,includedescriptorclasses class * { native <methods>; }
-keepclassmembers enum * { public static **[] values(); public static ** valueOf(java.lang.String); }

# هستهٔ Xray (libv2ray.aar) با نام از جاوا و از خودش صدا زده می‌شود.
-keep class go.** { *; }
-keep class libv2ray.** { *; }
-dontwarn go.**
-dontwarn libv2ray.**

# هشدارهای کتابخانه‌های اختیاری را نادیده بگیر
-dontwarn org.conscrypt.**
-dontwarn javax.annotation.**
