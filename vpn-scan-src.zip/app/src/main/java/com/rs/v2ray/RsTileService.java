package com.rs.v2ray;

import android.app.PendingIntent;
import android.content.Intent;
import android.net.VpnService;
import android.os.Build;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

/** کاشی «VPN Scan» در تنظیمات سریع گوشی: با یک لمس وصل / قطع به آخرین سرور */
public class RsTileService extends TileService {

    @Override
    public void onStartListening() { refresh(); }

    private void refresh() {
        Tile t = getQsTile(); if (t == null) return;
        String st = RsVpnService.state;
        boolean on = "on".equals(st) || "connecting".equals(st);
        t.setState(on ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
        t.setLabel("VPN Scan");
        if (Build.VERSION.SDK_INT >= 29) {
            String n = RsVpnService.name;
            t.setSubtitle("connecting".equals(st) ? (RsVpnService.english ? "Connecting…" : "در حال اتصال…")
                : "on".equals(st) ? (n == null || n.isEmpty() ? (RsVpnService.english ? "Connected" : "وصل است") : n)
                : (RsVpnService.english ? "Off" : "قطع"));
        }
        t.updateTile();
    }

    @Override
    public void onClick() {
        String st = RsVpnService.state;
        if ("on".equals(st) || "connecting".equals(st) || RsVpnService.killHold) {
            try { startService(new Intent(this, RsVpnService.class).setAction(RsVpnService.ACT_STOP)); } catch (Exception ignored) { }
            return;
        }
        boolean ready = false;
        try { ready = VpnService.prepare(this) == null; } catch (Exception ignored) { }
        // آخرین اتصال ذخیره نشده → برنامه باز شود؛ حالت «فقط پروکسی» اجازهٔ VPN لازم ندارد
        org.json.JSONObject last = RsVpnService.loadLast(this);
        if (last == null) { openApp(); return; }
        org.json.JSONObject o = last.optJSONObject("opts");
        if (o != null && o.optBoolean("proxy")) ready = true;
        if (!ready) { openApp(); return; }
        try {
            Intent i = new Intent(this, RsVpnService.class).setAction(RsVpnService.ACT_RESUME);
            startForegroundService(i);
            Tile t = getQsTile(); if (t != null) { t.setState(Tile.STATE_ACTIVE); t.updateTile(); }
        } catch (Exception e) { openApp(); }
    }

    private void openApp() {
        Intent i = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            if (Build.VERSION.SDK_INT >= 34)
                startActivityAndCollapse(PendingIntent.getActivity(this, 7, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
            else startActivityAndCollapse(i);
        } catch (Exception ignored) { }
    }
}
