package com.rs.v2ray;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashSet;

/**
 * تونل DNS برای نت ملی: موتورهای MasterDNS / StormDNS / CottenDNS (MIT) و Soar (Apache-2.0)
 * هر موتور یک پردازهٔ جدا (lib*.so) است که یک پروکسی SOCKS5 محلی باز می‌کند.
 * کانفیگ هر موتور از پروفایل کاربر (لینک soar:// ، masterdns:// ، … ) ساخته می‌شود؛ هیچ کانفیگی داخل برنامه نیست.
 */
final class RsTun {
    private RsTun() { }

    static final String[][] ENGINES = {     // engine, فایل اجرایی
        {"masterdns", "libmdns.so"}, {"stormdns", "libstorm.so"}, {"cottendns", "libcotten.so"}, {"soar", "libsoar.so"},
    };

    static volatile Process proc;
    static volatile int port = 0;
    static volatile String engine = "", name = "", pid = "";
    static volatile long since = 0;
    private static final StringBuilder log = new StringBuilder();
    private static File conf, res;

    static String bin(String engine) {
        for (String[] e : ENGINES) if (e[0].equals(engine)) return e[1];
        return null;
    }

    /** کدام موتورها داخل این نسخه از برنامه هستند */
    static JSONObject available(Context c) {
        JSONObject o = new JSONObject();
        try {
            for (String[] e : ENGINES) o.put(e[0], new File(c.getApplicationInfo().nativeLibraryDir, e[1]).exists());
        } catch (Exception ignored) { }
        return o;
    }

    private static void hlog(String s) {
        synchronized (log) { log.append(s); if (log.length() > 16000) log.delete(0, log.length() - 12000); }
    }
    static String logs() { synchronized (log) { return log.toString(); } }

    static String q(String s) { return JSONObject.quote(s == null ? "" : s); }

    /** کانفیگ TOML برای MasterDNS / StormDNS / CottenDNS */
    static String toml(JSONObject srv, int listen) {
        StringBuilder t = new StringBuilder();
        JSONArray doms = srv.optJSONArray("domains");
        t.append("DOMAINS = [");
        if (doms != null && doms.length() > 0) for (int i = 0; i < doms.length(); i++) { if (i > 0) t.append(", "); t.append(q(doms.optString(i))); }
        else t.append(q(srv.optString("domain")));
        t.append("]\n");
        t.append("DATA_ENCRYPTION_METHOD = ").append(srv.optInt("encryption_method", 1)).append('\n');
        t.append("ENCRYPTION_KEY = ").append(q(srv.optString("encryption_key"))).append('\n');
        t.append("PROTOCOL_TYPE = \"SOCKS5\"\nLISTEN_IP = \"127.0.0.1\"\nLISTEN_PORT = ").append(listen).append('\n');
        t.append("SOCKS5_AUTH = false\nLOCAL_DNS_ENABLED = false\nSAVE_MTU_SERVERS_TO_FILE = false\nLOCAL_DNS_CACHE_PERSIST_TO_FILE = false\n");
        return t.toString();
    }

    /** کانفیگ JSON برای soarsocks */
    static String soarJson(JSONObject p, JSONArray resolvers, int listen) throws Exception {
        JSONObject srv = p.optJSONObject("server");
        JSONObject o = new JSONObject();
        o.put("domain", srv.optString("domain"));
        o.put("public_key", srv.optString("public_key"));
        o.put("resolvers", resolvers);
        o.put("listen", "127.0.0.1:" + listen);
        JSONObject s = p.optJSONObject("soarSettings");
        o.put("soarSettings", s == null ? new JSONObject().put("country", "IR") : s);
        return o.toString();
    }

    /**
     * یک پروفایل را بالا می‌آورد و تست می‌کند (پاسخ از داخل تونل).
     * خروجی: {"ok":true,"port":…,"ms":…} یا {"ok":false,"err":"…"}
     */
    static synchronized String start(Context c, String profileJson, String extraResolversJson, int timeoutMs) {
        JSONObject out = new JSONObject();
        try {
            stop();
            JSONObject p = new JSONObject(profileJson);
            if (p.has("profile")) p = p.getJSONObject("profile");
            String eng = p.optString("engine", "soar").toLowerCase(java.util.Locale.US);
            String b = bin(eng);
            if (b == null) throw new Exception("unknown engine: " + eng);
            File f = new File(c.getApplicationInfo().nativeLibraryDir, b);
            if (!f.exists()) throw new Exception(english() ? "this engine isn't in this build of the app" : "این موتور در این نسخهٔ برنامه نیست");
            JSONObject srv = p.optJSONObject("server");
            if (srv == null || srv.optString("domain").isEmpty()) throw new Exception(english() ? "profile has no domain" : "پروفایل دامنه ندارد");
            // resolverها: پروفایل + بانک برنامه + DNS گوشی
            LinkedHashSet<String> rs = new LinkedHashSet<>();
            JSONArray pr = p.optJSONArray("resolvers");
            if (pr != null) for (int i = 0; i < pr.length(); i++) rs.add(pr.optString(i).trim());
            try { JSONArray ex = new JSONArray(extraResolversJson); for (int i = 0; i < ex.length(); i++) rs.add(ex.optString(i).trim()); } catch (Exception ignored) { }
            rs.addAll(RsDns.resolvers(c, null));
            rs.remove("");
            JSONArray rsa = new JSONArray(); for (String r : rs) rsa.put(r);
            int lp = freePort();
            File dir = new File(c.getFilesDir(), "tun"); dir.mkdirs();
            conf = new File(dir, "soar".equals(eng) ? "client.json" : "client_config.toml");
            res = new File(dir, "client_resolvers.txt");
            try (FileOutputStream o = new FileOutputStream(conf)) {
                o.write(("soar".equals(eng) ? soarJson(p, rsa, lp) : toml(srv, lp)).getBytes(StandardCharsets.UTF_8));
            }
            StringBuilder rl = new StringBuilder(); for (String r : rs) rl.append(r).append('\n');
            try (FileOutputStream o = new FileOutputStream(res)) { o.write(rl.toString().getBytes(StandardCharsets.UTF_8)); }
            ProcessBuilder pb = "soar".equals(eng)
                ? new ProcessBuilder(f.getAbsolutePath(), "-c", conf.getAbsolutePath())
                : new ProcessBuilder(f.getAbsolutePath(), "-config", conf.getAbsolutePath(), "-resolvers", res.getAbsolutePath());
            pb.directory(dir); pb.redirectErrorStream(true);
            pb.environment().put("HOME", dir.getAbsolutePath());
            synchronized (log) { log.setLength(0); }
            hlog("--- " + eng + " · " + p.optString("name") + " · " + rs.size() + " resolvers ---\n");
            final Process pr2 = pb.start();
            proc = pr2; engine = eng; name = p.optString("name"); port = lp;
            Thread rd = new Thread(() -> {
                try (InputStream in = pr2.getInputStream()) {
                    byte[] buf = new byte[4096]; int n;
                    while ((n = in.read(buf)) > 0) hlog(new String(buf, 0, n, StandardCharsets.UTF_8).replaceAll("\u001B\\[[0-9;]*m", "").replaceAll("<[a-z/]+>", ""));
                } catch (Exception ignored) { }
            });
            rd.setDaemon(true); rd.start();
            // صبر برای باز شدن پورت SOCKS (موتورهای MasterDNS اول MTU را تست می‌کنند)
            long until = System.currentTimeMillis() + timeoutMs;
            boolean open = false;
            while (System.currentTimeMillis() < until && pr2.isAlive()) {
                try (java.net.Socket so = new java.net.Socket()) { so.connect(new InetSocketAddress("127.0.0.1", lp), 300); open = true; break; }
                catch (Exception e) { Thread.sleep(300); }
            }
            if (!open) throw new Exception(lastLine(english() ? "tunnel didn't start" : "تونل بالا نیامد"));
            // تست واقعی: یک درخواست کوچک از داخل تونل
            long t0 = System.currentTimeMillis();
            int left = (int) Math.max(8000, until - System.currentTimeMillis());
            if (!probe(lp, left)) throw new Exception(lastLine(english() ? "tunnel is up but nothing comes back" : "تونل بالا آمد ولی جوابی از داخلش نیامد"));
            since = System.currentTimeMillis();
            out.put("ok", true); out.put("port", lp); out.put("ms", System.currentTimeMillis() - t0); out.put("engine", eng);
        } catch (Throwable t) {
            stop();
            try { out.put("ok", false); out.put("err", String.valueOf(t.getMessage())); } catch (Exception ignored) { }
        }
        return out.toString();
    }

    private static String lastLine(String def) {
        String l = logs().trim();
        if (l.isEmpty()) return def;
        String[] ls = l.split("\n");
        for (int i = ls.length - 1; i >= 0; i--) if (ls[i].contains("ERROR") || ls[i].contains("rror")) return def + " · " + ls[i].replaceAll("^\\S+ \\S+ ", "").trim();
        return def;
    }

    /** یک درخواست HTTP کوچک از داخل SOCKS تونل */
    static boolean probe(int p, int timeoutMs) {
        HttpURLConnection h = null;
        try {
            java.net.Proxy px = new java.net.Proxy(java.net.Proxy.Type.SOCKS, new InetSocketAddress("127.0.0.1", p));
            h = (HttpURLConnection) new URL("http://www.gstatic.com/generate_204").openConnection(px);
            h.setConnectTimeout(timeoutMs); h.setReadTimeout(timeoutMs); h.setUseCaches(false);
            int code = h.getResponseCode();
            return code == 204 || code == 200;
        } catch (Exception e) { return false; }
        finally { if (h != null) h.disconnect(); }
    }

    static synchronized void stop() {
        Process p = proc; proc = null;
        if (p != null) { p.destroy(); try { if (!p.waitFor(1500, java.util.concurrent.TimeUnit.MILLISECONDS)) p.destroyForcibly(); } catch (Exception ignored) { } }
        port = 0; since = 0; engine = ""; name = "";
    }

    static boolean running() { Process p = proc; return p != null && p.isAlive() && port > 0; }

    static String state() {
        try {
            JSONObject o = new JSONObject();
            o.put("on", running()); o.put("port", running() ? port : 0); o.put("engine", engine); o.put("name", name); o.put("since", since);
            return o.toString();
        } catch (Exception e) { return "{\"on\":false}"; }
    }

    private static boolean english() { return RsVpnService.english; }

    private static int freePort() {
        try (java.net.ServerSocket s = new java.net.ServerSocket(0, 1, java.net.InetAddress.getByName("127.0.0.1"))) { return s.getLocalPort(); }
        catch (Exception e) { return 24000 + (int) (Math.random() * 20000); }
    }
}
