package com.rs.v2ray;

import java.io.DataInputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.security.SecureRandom;

/**
 * تست واقعی سرور OpenVPN: بستهٔ شروع دست‌دادن (P_CONTROL_HARD_RESET_CLIENT_V2) فرستاده می‌شود
 * و اگر سرور با HARD_RESET_SERVER_V2 جواب داد، یعنی سرور OpenVPN واقعاً زنده است.
 * (سرورهایی که tls-auth / tls-crypt دارند به این بسته جواب نمی‌دهند؛ برای آن‌ها فقط اتصال TCP سنجیده می‌شود.)
 */
final class RsOvpn {
    private RsOvpn() { }
    private static final SecureRandom rnd = new SecureRandom();

    static byte[] hardReset() {
        byte[] p = new byte[1 + 8 + 1 + 4];
        p[0] = (byte) (7 << 3);                       // P_CONTROL_HARD_RESET_CLIENT_V2, key_id 0
        byte[] sid = new byte[8]; rnd.nextBytes(sid);
        System.arraycopy(sid, 0, p, 1, 8);
        p[9] = 0;                                     // ack array length
        // message packet-id = 0 (4 bytes)
        return p;
    }

    private static boolean isServerReset(byte[] b, int off, int len) {
        return len >= 10 && ((b[off] & 0xff) >> 3) == 8;    // P_CONTROL_HARD_RESET_SERVER_V2
    }

    /** زمان پاسخ (ms)؛ -1 = جواب نداد ؛ -2 = فقط پورت TCP باز است (سرور به بستهٔ بی‌امضا جواب نداد) */
    static long probe(String host, int port, boolean tcp, int timeoutMs) {
        byte[] pk = hardReset();
        long t0 = System.nanoTime();
        if (!tcp) {
            try (DatagramSocket s = new DatagramSocket()) {
                s.setSoTimeout(timeoutMs);
                InetAddress a = InetAddress.getByName(host);
                for (int i = 0; i < 2; i++) {                // UDP: دو بار (اگر بسته گم شد)
                    s.send(new DatagramPacket(pk, pk.length, a, port));
                    byte[] buf = new byte[2048];
                    try {
                        DatagramPacket r = new DatagramPacket(buf, buf.length);
                        s.receive(r);
                        if (isServerReset(buf, 0, r.getLength())) return Math.max(1, (System.nanoTime() - t0) / 1_000_000);
                    } catch (java.net.SocketTimeoutException ignored) { }
                }
            } catch (Exception ignored) { }
            return -1;
        }
        try (Socket s = new Socket()) {
            s.connect(new InetSocketAddress(host, port), timeoutMs);
            long conn = Math.max(1, (System.nanoTime() - t0) / 1_000_000);
            s.setSoTimeout(timeoutMs);
            byte[] f = new byte[pk.length + 2];
            f[0] = 0; f[1] = (byte) pk.length;
            System.arraycopy(pk, 0, f, 2, pk.length);
            OutputStream o = s.getOutputStream(); o.write(f); o.flush();
            try {
                DataInputStream in = new DataInputStream(s.getInputStream());
                int len = in.readUnsignedShort();
                byte[] b = new byte[Math.min(len, 4096)];
                in.readFully(b);
                if (isServerReset(b, 0, b.length)) return Math.max(1, (System.nanoTime() - t0) / 1_000_000);
            } catch (Exception ignored) { }
            return -2 - conn;    // پورت باز ولی دست‌دادن تأیید نشد (−۲−زمان اتصال)
        } catch (Exception e) { return -1; }
    }
}
