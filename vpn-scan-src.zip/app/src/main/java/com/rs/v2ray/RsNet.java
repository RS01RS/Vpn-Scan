package com.rs.v2ray;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ConcurrentHashMap;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

/**
 * دریافت منابع با DNS امن (DoH).
 * در ایران DNS معمولی برای سایت‌های فیلترشده یا جواب نمی‌دهد یا IP صفحهٔ فیلتر (10.10.34.x) را می‌دهد.
 * این کلاس اگر جواب DNS گوشی نبود یا مسموم بود، IP واقعی را از DoH (کلادفلر / گوگل، با خود IP، بدون نیاز به DNS)
 * می‌گیرد و مستقیم به همان IP با SNI درست وصل می‌شود.
 */
final class RsNet {
    private RsNet() { }

    /** روشن / خاموش از تنظیمات (پیش‌فرض روشن) */
    static volatile boolean doh = true;
    /** آمار ساده برای گزارش: چند بار مستقیم، چند بار با DoH */
    static volatile int nDirect = 0, nDoh = 0, nFail = 0;

    static String[][] DOH = {
        {"1.1.1.1", "/dns-query?name=%s&type=%s"},
        {"8.8.8.8", "/resolve?name=%s&type=%s"},
        {"1.0.0.1", "/dns-query?name=%s&type=%s"},
        {"8.8.4.4", "/resolve?name=%s&type=%s"},
    };
    private static final ConcurrentHashMap<String, Object[]> cache = new ConcurrentHashMap<>();   // host → {ip, until}
    private static final String UA = "Mozilla/5.0 (Linux; Android 14) VPN-Scan/1.0";
    /** برای تست: کارخانهٔ TLS (پیش‌فرض سیستم) */
    static SSLSocketFactory tls = HttpsURLConnection.getDefaultSSLSocketFactory();
    static int dohPort = 443;
    /** برای تست: بررسی نام گواهی، و اجازهٔ IP محلی */
    static javax.net.ssl.HostnameVerifier verifier = HttpsURLConnection.getDefaultHostnameVerifier();
    static boolean allowLocal = false;

    /** آیا این IP «مسموم» است؟ (صفحهٔ فیلتر، شبکهٔ خصوصی، یا نامعتبر) */
    static boolean poisoned(InetAddress a) {
        if (a == null) return true;
        if (allowLocal && a.isLoopbackAddress()) return false;
        byte[] b = a.getAddress();
        if (a.isAnyLocalAddress() || a.isLoopbackAddress() || a.isSiteLocalAddress() || a.isLinkLocalAddress()) return true;
        if (b.length == 4) {
            int x = b[0] & 255, y = b[1] & 255;
            if (x == 10 || x == 0 || (x == 100 && y >= 64 && y < 128) || x >= 224) return true;
        }
        return false;
    }

    private static boolean isIpLiteral(String h) { return h.matches("[0-9.]+") || h.contains(":"); }

    /** IP با DNS گوشی؛ null اگر جواب نداد یا مسموم بود */
    static String sysResolve(String host) {
        try {
            for (InetAddress a : InetAddress.getAllByName(host)) if (a.getAddress().length == 4 && !poisoned(a)) return a.getHostAddress();
        } catch (Exception ignored) { }
        return null;
    }

    /** IP با DoH (چند سرور به نوبت)؛ null اگر هیچ‌کدام جواب نداد */
    static String dohResolve(String host, int timeoutMs) {
        Object[] c = cache.get(host);
        if (c != null && (Long) c[1] > System.currentTimeMillis()) return (String) c[0];
        for (String[] d : DOH) {
            try {
                String path = String.format(Locale.US, d[1], java.net.URLEncoder.encode(host, "UTF-8"), "A");
                Resp r = raw("https", d[0], d[0], dohPort, path, Math.min(timeoutMs, 6000), 64_000,
                             new String[]{"Accept", "application/dns-json"});
                if (r == null || r.code != 200) continue;
                JSONArray ans = new JSONObject(r.body).optJSONArray("Answer");
                if (ans == null) continue;
                for (int i = 0; i < ans.length(); i++) {
                    JSONObject a = ans.getJSONObject(i);
                    if (a.optInt("type") != 1) continue;                     // فقط A
                    String ip = a.optString("data");
                    if (!ip.matches("\\d+\\.\\d+\\.\\d+\\.\\d+") || poisoned(InetAddress.getByName(ip))) continue;
                    long ttl = Math.max(60, Math.min(1800, a.optLong("TTL", 300)));
                    cache.put(host, new Object[]{ip, System.currentTimeMillis() + ttl * 1000});
                    return ip;
                }
            } catch (Exception ignored) { }
        }
        return null;
    }

    static final class Resp { int code; String location; String body; }

    /**
     * دریافت متن. اول مستقیم (DNS گوشی)؛ اگر DNS جواب نداد / مسموم بود / اتصال نشد → DoH و اتصال مستقیم به IP واقعی.
     * maxBytes > 0 یعنی فقط همین مقدار از ابتدای فایل.
     */
    static String get(String url, int timeoutMs, int maxBytes) {
        int limit = maxBytes > 0 ? maxBytes : 4_000_000;
        String host;
        try { host = new URL(url).getHost(); } catch (Exception e) { return null; }
        boolean literal = isIpLiteral(host);
        boolean sysOk = literal || !doh || sysResolve(host) != null;
        if (sysOk) {
            String t = direct(url, timeoutMs, maxBytes, limit);
            if (t != null) { nDirect++; return t; }
            if (literal || !doh) { nFail++; return null; }
        }
        // DNS گوشی جواب نداد / مسموم بود / اتصال نشد → DoH
        try {
            String t = viaDoh(url, timeoutMs, maxBytes, limit, 0);
            if (t != null) { nDoh++; return t; }
        } catch (Exception ignored) { }
        nFail++;
        return null;
    }

    /** همان روش قبلی برنامه (HttpURLConnection) */
    static String direct(String url, int timeoutMs, int maxBytes, int limit) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(Math.min(timeoutMs, 15000));
            c.setReadTimeout(timeoutMs);
            c.setInstanceFollowRedirects(true);
            c.setRequestProperty("User-Agent", UA);
            if (maxBytes > 0 && maxBytes < 4_000_000) c.setRequestProperty("Range", "bytes=0-" + (maxBytes - 1));
            if (c.getResponseCode() / 100 != 2) return null;
            try (InputStream in = c.getInputStream()) { return readAll(in, limit); }
        } catch (Exception e) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private static String viaDoh(String url, int timeoutMs, int maxBytes, int limit, int hops) throws Exception {
        if (hops > 4) return null;
        URL u = new URL(url);
        String host = u.getHost();
        boolean https = "https".equalsIgnoreCase(u.getProtocol());
        int port = u.getPort() > 0 ? u.getPort() : (https ? 443 : 80);
        String ip = isIpLiteral(host) ? host : dohResolve(host, timeoutMs);
        if (ip == null) return null;
        String path = u.getFile().isEmpty() ? "/" : u.getFile();
        String[] hdr = maxBytes > 0 && maxBytes < 4_000_000 ? new String[]{"Range", "bytes=0-" + (maxBytes - 1)} : new String[0];
        Resp r = raw(https ? "https" : "http", host, ip, port, path, timeoutMs, limit, hdr);
        if (r == null) return null;
        if (r.code / 100 == 3 && r.location != null) return viaDoh(new URL(u, r.location).toString(), timeoutMs, maxBytes, limit, hops + 1);
        return r.code / 100 == 2 ? r.body : null;
    }

    /** درخواست HTTP/1.1 ساده روی سوکت: وصل به ip، ولی SNI و Host = host (با بررسی کامل گواهی) */
    static Resp raw(String scheme, String host, String ip, int port, String path, int timeoutMs, int limit, String[] hdr) {
        Socket s = null;
        try {
            s = new Socket();
            s.connect(new InetSocketAddress(InetAddress.getByName(ip), port), Math.min(timeoutMs, 10000));
            s.setSoTimeout(timeoutMs);
            if ("https".equals(scheme)) {
                SSLSocket ss = (SSLSocket) tls.createSocket(s, host, port, true);
                ss.startHandshake();
                if (!verifier.verify(host, ss.getSession()))
                    throw new javax.net.ssl.SSLPeerUnverifiedException("hostname mismatch: " + host);
                s = ss;
            }
            StringBuilder q = new StringBuilder();
            q.append("GET ").append(path).append(" HTTP/1.1\r\nHost: ").append(host).append("\r\nUser-Agent: ").append(UA)
             .append("\r\nAccept-Encoding: identity\r\nConnection: close\r\n");
            for (int i = 0; i + 1 < hdr.length; i += 2) q.append(hdr[i]).append(": ").append(hdr[i + 1]).append("\r\n");
            q.append("\r\n");
            OutputStream o = s.getOutputStream();
            o.write(q.toString().getBytes(StandardCharsets.US_ASCII)); o.flush();
            InputStream in = new BufferedInputStream(s.getInputStream());
            String status = line(in);
            if (status == null || !status.startsWith("HTTP/")) return null;
            Resp r = new Resp();
            String[] sp = status.split(" ");
            r.code = sp.length > 1 ? Integer.parseInt(sp[1].trim()) : 0;
            long len = -1; boolean chunked = false;
            String l;
            while ((l = line(in)) != null && !l.isEmpty()) {
                int k = l.indexOf(':'); if (k < 0) continue;
                String n = l.substring(0, k).trim().toLowerCase(Locale.US), v = l.substring(k + 1).trim();
                if (n.equals("content-length")) { try { len = Long.parseLong(v); } catch (Exception ignored) { } }
                else if (n.equals("transfer-encoding") && v.toLowerCase(Locale.US).contains("chunked")) chunked = true;
                else if (n.equals("location")) r.location = v;
            }
            if (r.code / 100 == 3) { r.body = ""; return r; }
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            if (chunked) {
                while (out.size() < limit) {
                    String h = line(in); if (h == null) break;
                    int semi = h.indexOf(';'); if (semi >= 0) h = h.substring(0, semi);
                    h = h.trim(); if (h.isEmpty()) continue;
                    int n = Integer.parseInt(h, 16); if (n == 0) break;
                    copy(in, out, Math.min(n, limit - out.size()));
                    if (out.size() >= limit) break;
                    line(in);
                }
            } else copy(in, out, len >= 0 ? (int) Math.min(len, limit) : limit);
            r.body = new String(out.toByteArray(), StandardCharsets.UTF_8);
            return r;
        } catch (Exception e) {
            return null;
        } finally {
            try { if (s != null) s.close(); } catch (Exception ignored) { }
        }
    }

    private static String line(InputStream in) throws java.io.IOException {
        StringBuilder b = new StringBuilder(); int c;
        while ((c = in.read()) >= 0) { if (c == '\n') break; if (c != '\r') b.append((char) c); if (b.length() > 16384) break; }
        return c < 0 && b.length() == 0 ? null : b.toString();
    }

    private static void copy(InputStream in, ByteArrayOutputStream out, int n) throws java.io.IOException {
        byte[] buf = new byte[16384]; int k;
        while (n > 0 && (k = in.read(buf, 0, Math.min(buf.length, n))) > 0) { out.write(buf, 0, k); n -= k; }
    }

    static String readAll(InputStream in, int limit) throws java.io.IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[16384]; int n, total = 0;
        while ((n = in.read(buf)) > 0) { out.write(buf, 0, n); total += n; if (total >= limit) break; }
        return new String(out.toByteArray(), StandardCharsets.UTF_8);
    }

    static String stats() {
        return "{\"doh\":" + doh + ",\"direct\":" + nDirect + ",\"viaDoh\":" + nDoh + ",\"fail\":" + nFail + "}";
    }

    /** برای تست بیرون از اندروید */
    static List<String> selfTestPoison() {
        List<String> o = new ArrayList<>();
        for (String ip : new String[]{"10.10.34.35", "10.10.34.36", "192.168.1.1", "127.0.0.1", "185.199.108.133", "0.0.0.0", "100.64.1.1"}) {
            try { o.add(ip + "=" + poisoned(InetAddress.getByName(ip))); } catch (Exception e) { o.add(ip + "=err"); }
        }
        return o;
    }
}
