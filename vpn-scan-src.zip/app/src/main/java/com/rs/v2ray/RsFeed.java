package com.rs.v2ray;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashSet;
import java.util.concurrent.TimeUnit;

/**
 * thefeed (github.com/sartoopjj/thefeed، MIT): پیام‌های کانال‌های تلگرامِ یک سرور thefeed از راه DNS.
 * libfeed.so (برنامهٔ rsfeed) یک بار اجرا می‌شود و JSON کانال‌ها و پیام‌ها را چاپ می‌کند.
 */
final class RsFeed {
    private RsFeed() { }

    static boolean available(Context c) { return new File(c.getApplicationInfo().nativeLibraryDir, "libfeed.so").exists(); }

    /** profile: {"domain","key","sk","extra":[…],"resolvers":[…]} → {"ok":true,"channels":[{name,title,msgs:[…]}]} */
    static String fetch(Context c, String profileJson, String bankJson, int timeoutSec) {
        Process p = null;
        try {
            File bin = new File(c.getApplicationInfo().nativeLibraryDir, "libfeed.so");
            if (!bin.exists()) return "{\"ok\":false,\"err\":\"" + (RsVpnService.english ? "thefeed isn't in this build of the app" : "thefeed در این نسخهٔ برنامه نیست") + "\"}";
            JSONObject pr = new JSONObject(profileJson);
            LinkedHashSet<String> rs = new LinkedHashSet<>();
            JSONArray a = pr.optJSONArray("resolvers");
            if (a != null) for (int i = 0; i < a.length(); i++) rs.add(a.optString(i).trim());
            try { JSONArray b = new JSONArray(bankJson); for (int i = 0; i < b.length(); i++) rs.add(b.optString(i).trim()); } catch (Exception ignored) { }
            rs.addAll(RsDns.resolvers(c, null));
            rs.remove("");
            JSONObject cfg = new JSONObject();
            cfg.put("domain", pr.optString("domain"));
            cfg.put("key", pr.optString("key"));
            cfg.put("sk", pr.optString("sk"));
            cfg.put("extra", pr.optJSONArray("extra") == null ? new JSONArray() : pr.optJSONArray("extra"));
            JSONArray ra = new JSONArray(); int n = 0; for (String r : rs) { if (n++ >= 300) break; ra.put(r); }
            cfg.put("resolvers", ra);
            cfg.put("timeoutSec", Math.max(20, timeoutSec - 5));
            File dir = new File(c.getFilesDir(), "feed"); dir.mkdirs();
            File cf = new File(dir, "rsfeed.json");
            try (FileOutputStream o = new FileOutputStream(cf)) { o.write(cfg.toString().getBytes(StandardCharsets.UTF_8)); }
            ProcessBuilder pb = new ProcessBuilder(bin.getAbsolutePath(), "-c", cf.getAbsolutePath());
            pb.directory(dir);
            pb.redirectError(new File(dir, "rsfeed.log"));   // (Redirect.DISCARD در اندروید نیست)
            pb.environment().put("HOME", dir.getAbsolutePath());
            p = pb.start();
            final Process pp = p;
            final StringBuilder out = new StringBuilder();
            Thread rd = new Thread(() -> {
                try (InputStream in = pp.getInputStream()) {
                    byte[] buf = new byte[16384]; int k;
                    while ((k = in.read(buf)) > 0) { synchronized (out) { if (out.length() < 6_000_000) out.append(new String(buf, 0, k, StandardCharsets.UTF_8)); } }
                } catch (Exception ignored) { }
            });
            rd.start();
            if (!p.waitFor(timeoutSec, TimeUnit.SECONDS)) { p.destroyForcibly(); return "{\"ok\":false,\"err\":\"timeout\"}"; }
            rd.join(3000);
            String s; synchronized (out) { s = out.toString().trim(); }
            int nl = s.lastIndexOf('\n'); if (nl >= 0) s = s.substring(nl + 1);
            return s.startsWith("{") ? s : "{\"ok\":false,\"err\":\"no output\"}";
        } catch (Throwable t) {
            if (p != null) p.destroyForcibly();
            return "{\"ok\":false,\"err\":" + JSONObject.quote(String.valueOf(t.getMessage())) + "}";
        }
    }
}
