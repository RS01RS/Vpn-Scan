package com.rs.v2ray;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.VpnService;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.service.quicksettings.TileService;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * VPN داخل خود برنامه: هستهٔ Xray (libv2ray، همان هستهٔ v2rayNG) با ورودی TUN،
 * یا فقط پروکسی SOCKS/HTTP (بدون TUN).
 * ترافیک خود VPN Scan از VPN رد نمی‌شود تا اسکن و تست‌ها مستقیم بمانند.
 *
 * - چند سرور جایگزین: اگر سرور اول وصل نشد یا وسط کار جواب نداد، خودکار سرور بعدی
 * - TUN بین جابه‌جایی سرورها باز می‌ماند (ترافیک بیرون نمی‌زند)؛ با «قطع اضطراری» حتی موقع قطعی هم باز می‌ماند
 * - سرعت و حجم مصرف (روی کارت و اعلان)، تاریخچهٔ مصرف روزانه، هشدار سقف ماهانه
 * - تقسیم برنامه‌ها، دسترسی به شبکهٔ محلی، MTU، فایل لاگ هسته
 */
public class RsVpnService extends VpnService {

    static final String ACT_START = "com.rs.v2ray.VPN_START";
    static final String ACT_STOP = "com.rs.v2ray.VPN_STOP";
    static final String ACT_RESUME = "com.rs.v2ray.VPN_RESUME";
    private static final String CH = "rs_vpn";
    private static final String CH2 = "rs_vpn_alert";
    private static final int NID = 9;
    private static final int NID_ALERT = 10;
    static final String PREFS = "rs_vpn";
    static final String USAGE = "rs_usage";

    // وضعیت برای صفحه: off | connecting | on | error
    static volatile String state = "off";
    static volatile String name = "";
    static volatile String err = "";
    static volatile String key = "";
    static volatile long since = 0;
    static volatile String core = "x26";
    static volatile boolean proxyOn = false;
    static volatile int proxyPort = 0;
    static volatile boolean proxyShare = false;
    // ترافیک: کل از شروع اتصال و سرعت لحظه‌ای (بایت / بایت بر ثانیه)
    static volatile long rxTotal = 0, txTotal = 0, rxRate = 0, txRate = 0;
    // خلاصهٔ عملکرد
    static volatile int switches = 0, pingN = 0, pingFail = 0;
    static volatile long pingSum = 0, lastPing = 0;
    static volatile boolean killHold = false;
    static volatile Runnable listener;
    static volatile RsVpnService self;
    static volatile boolean english = false;
    private static final StringBuilder helperLog = new StringBuilder();
    private static String tr(String fa, String en) { return english ? en : fa; }

    /** یک سرور آمادهٔ اتصال: کانفیگ هستهٔ اصلی (+ کانفیگ هستهٔ کمکی برای Xray 25 / sing-box) */
    static final class Cand {
        String cfg, hc, hcfg, name, k;
        static Cand of(JSONObject o) {
            Cand c = new Cand();
            c.cfg = o.optString("cfg"); c.hc = o.optString("hc", "x26"); c.hcfg = o.optString("hcfg");
            c.name = o.optString("name"); c.k = o.optString("k");
            if (c.hc.isEmpty()) c.hc = "x26";
            return c;
        }
    }

    private ParcelFileDescriptor tun;
    private libv2ray.CoreController ctl;
    // هستهٔ کمکی (Xray 25 برای NPV یا sing-box برای Hiddify) که پشت TUN با SOCKS محلی کار می‌کند
    private Process helper;
    private java.io.File helperConf;
    // ورودی HTTP محلی داخل همان اتصال، فقط برای تست سرعت و IP از داخل VPN
    private volatile int httpPort = 0;
    private final Object lock = new Object();

    // تنظیمات اتصال فعلی
    private int mtu = 1500;
    private String appMode = "all";
    private final List<String> apps = new ArrayList<>();
    private boolean lan = false, kill = false, health = true, proxy = false, share = false;
    private long limitMb = 0;
    private final List<Cand> cands = new ArrayList<>();
    private int ci = 0;

    private volatile boolean stopping = false;
    private volatile boolean helperDied = false, netEvent = false;
    private final Object wake = new Object();
    private Thread supervisor, ticker;
    private ConnectivityManager.NetworkCallback netCb;
    private boolean fgStarted = false;

    static String stateJson() {
        try {
            JSONObject o = new JSONObject();
            o.put("state", state); o.put("name", name); o.put("err", err); o.put("since", since); o.put("core", core); o.put("k", key);
            o.put("rx", rxTotal); o.put("tx", txTotal); o.put("rxr", rxRate); o.put("txr", txRate);
            o.put("proxy", proxyOn); o.put("port", proxyPort); o.put("share", proxyShare);
            o.put("sw", switches); o.put("ping", lastPing); o.put("avg", pingN > 0 ? pingSum / pingN : 0); o.put("pf", pingFail);
            o.put("hold", killHold);
            return o.toString();
        } catch (Exception e) { return "{\"state\":\"off\"}"; }
    }

    private void emit() {
        Runnable l = listener; if (l != null) l.run();
        try { TileService.requestListeningState(this, new ComponentName(this, RsTileService.class)); } catch (Throwable ignored) { }
    }

    private void set(String st, String e) { state = st; err = e == null ? "" : e; emit(); }

    @Override
    public void onCreate() { super.onCreate(); self = this; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String act = intent != null ? intent.getAction() : null;
        if (ACT_STOP.equals(act)) {
            stopping = true;
            state = "off"; err = "";
            synchronized (wake) { wake.notifyAll(); }
            new Thread(() -> { stopVpn(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); }).start();
            return START_NOT_STICKY;
        }
        JSONObject req;
        if (ACT_START.equals(act)) {
            req = new JSONObject();
            try {
                req.put("cfg", intent.getStringExtra("cfg"));
                req.put("name", nz(intent.getStringExtra("name")));
                req.put("hc", nz(intent.getStringExtra("helperCore")));
                req.put("hcfg", nz(intent.getStringExtra("helperCfg")));
                req.put("k", nz(intent.getStringExtra("k")));
                String op = intent.getStringExtra("opts");
                req.put("opts", op == null || op.isEmpty() ? new JSONObject() : new JSONObject(op));
            } catch (Exception e) { req = null; }
            if (req != null) saveLast(this, req);
        } else {
            // کاشی تنظیمات سریع، یا «VPN همیشه روشن» اندروید: آخرین اتصال
            req = loadLast(this);
        }
        if (req == null || req.optString("cfg").isEmpty()) {
            set("error", tr("هنوز سروری برای اتصال انتخاب نشده؛ برنامه را باز کن.", "No server chosen yet; open the app."));
            stopSelf();
            return START_NOT_STICKY;
        }
        stopping = false;
        name = req.optString("name");
        set("connecting", "");
        showNotification(tr("در حال اتصال…", "Connecting…"));
        final JSONObject r = req;
        new Thread(() -> begin(r)).start();
        return START_NOT_STICKY;
    }

    private static String nz(String s) { return s == null ? "" : s; }

    static void saveLast(Context c, JSONObject req) {
        try { c.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("last", req.toString()).apply(); } catch (Exception ignored) { }
    }
    static JSONObject loadLast(Context c) {
        try { String s = c.getSharedPreferences(PREFS, MODE_PRIVATE).getString("last", null); return s == null ? null : new JSONObject(s); }
        catch (Exception e) { return null; }
    }

    private static int freePort() {
        try (java.net.ServerSocket s = new java.net.ServerSocket(0, 1, java.net.InetAddress.getByName("127.0.0.1"))) { return s.getLocalPort(); }
        catch (Exception e) { return 21000 + (int) (Math.random() * 20000); }
    }

    // ---------- رنج IP ایران (از بانک داخلی برنامه) برای «دور زدن ایران» ----------
    private static String irJson;
    private String irList() {
        if (irJson != null) return irJson;
        StringBuilder sb = new StringBuilder();
        try (java.io.BufferedReader in = new java.io.BufferedReader(new java.io.InputStreamReader(getAssets().open("ir4.txt"), StandardCharsets.US_ASCII))) {
            String l;
            while ((l = in.readLine()) != null) {
                l = l.trim(); if (l.isEmpty()) continue;
                if (sb.length() > 0) sb.append(',');
                sb.append('"').append(l).append('"');
            }
        } catch (Exception ignored) { }
        if (sb.length() == 0) sb.append("\"127.0.0.2/32\"");
        irJson = sb.toString();
        return irJson;
    }

    private java.io.File logFile() { return new java.io.File(getFilesDir(), "core.log"); }

    private static void hlog(String s) {
        synchronized (helperLog) {
            helperLog.append(s);
            if (helperLog.length() > 12000) helperLog.delete(0, helperLog.length() - 9000);
        }
    }

    /** هستهٔ کمکی را با ورودی SOCKS روی پورت داده‌شده بالا می‌آورد؛ اگر نشد، Exception با خروجی هسته */
    private void startHelper(String hc, String hcfg, int port) throws Exception {
        String bin = "x25".equals(hc) ? "libxray25.so" : "libsingbox.so";
        java.io.File f = new java.io.File(getApplicationInfo().nativeLibraryDir, bin);
        if (!f.exists()) throw new Exception(tr("این هسته روی این گوشی نیست (فقط گوشی‌های ۶۴ بیتی)", "this core isn't available on this phone (64-bit only)"));
        helperConf = java.io.File.createTempFile("vpn_", ".json", getCacheDir());
        try (java.io.FileOutputStream o = new java.io.FileOutputStream(helperConf)) {
            o.write(hcfg.replace("\"__RSPORT__\"", String.valueOf(port)).getBytes(StandardCharsets.UTF_8));
        }
        ProcessBuilder pb = new ProcessBuilder(f.getAbsolutePath(), "run", "-c", helperConf.getAbsolutePath());
        pb.directory(getCacheDir()); pb.redirectErrorStream(true);
        pb.environment().put("XRAY_LOCATION_ASSET", getCacheDir().getAbsolutePath());
        pb.environment().put("HOME", getCacheDir().getAbsolutePath());
        helperDied = false;
        helper = pb.start();
        hlog("\n--- " + ("x25".equals(hc) ? "Xray 25" : "sing-box") + " ---\n");
        final Process pr = helper; final StringBuilder out = new StringBuilder();
        Thread rd = new Thread(() -> {
            try (java.io.InputStream in = pr.getInputStream()) {
                byte[] b = new byte[2048]; int n;
                while ((n = in.read(b)) > 0) {
                    String s = new String(b, 0, n, StandardCharsets.UTF_8).replaceAll("\u001B\\[[0-9;]*m", "");
                    synchronized (out) { if (out.length() < 4000) out.append(s); }
                    hlog(s);
                }
            } catch (Exception ignored) { }
            // اگر هستهٔ کمکی وسط اتصال بسته شد: سرور بعدی (اتصال پایدار) یا قطع
            if ("on".equals(state) && helper == pr && !stopping) {
                helperDied = true;
                synchronized (wake) { wake.notifyAll(); }
            }
        });
        rd.setDaemon(true); rd.start();
        long until = System.currentTimeMillis() + 6000;
        while (System.currentTimeMillis() < until) {
            if (!helper.isAlive()) break;
            try (java.net.Socket so = new java.net.Socket()) { so.connect(new java.net.InetSocketAddress("127.0.0.1", port), 200); return; }
            catch (Exception e) { Thread.sleep(80); }
        }
        Thread.sleep(150);
        String o; synchronized (out) { o = out.toString().trim(); }
        throw new Exception(o.isEmpty() ? "helper core didn't start" : o.substring(Math.max(0, o.length() - 240)));
    }

    private void stopHelper() {
        Process p = helper; helper = null;
        if (p != null) p.destroyForcibly();
        if (helperConf != null) { helperConf.delete(); helperConf = null; }
    }

    private void readOpts(JSONObject o) {
        if (o == null) o = new JSONObject();
        mtu = Math.max(1280, Math.min(9000, o.optInt("mtu", 1500)));
        appMode = o.optString("appMode", "all");
        apps.clear();
        JSONArray a = o.optJSONArray("apps");
        if (a != null) for (int i = 0; i < a.length(); i++) { String p = a.optString(i); if (!p.isEmpty() && !p.equals(getPackageName())) apps.add(p); }
        lan = o.optBoolean("lan", false);
        kill = o.optBoolean("kill", false);
        health = o.optBoolean("health", true);
        proxy = o.optBoolean("proxy", false);
        share = o.optBoolean("share", false);
        limitMb = o.optLong("limitMb", 0);
        proxyPort = o.optInt("port", 10808);
    }

    // ---------- شبکه‌های محلی که با «دسترسی به شبکه محلی» بیرون از VPN می‌مانند ----------
    private static final String[] LAN4 = {"10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "169.254.0.0/16", "224.0.0.0/4", "255.255.255.255/32"};

    private static long ip4(String s) {
        String[] p = s.split("\\."); long v = 0;
        for (String x : p) v = (v << 8) | Integer.parseInt(x);
        return v;
    }
    private static String ip4s(long v) { return ((v >> 24) & 255) + "." + ((v >> 16) & 255) + "." + ((v >> 8) & 255) + "." + (v & 255); }

    /** همهٔ IPv4 به‌جز رنج‌های داده‌شده، به صورت کمترین تعداد مسیر */
    static List<String[]> complement(String[] excl) {
        long[][] ex = new long[excl.length][2];
        for (int i = 0; i < excl.length; i++) {
            String[] q = excl[i].split("/"); int len = Integer.parseInt(q[1]);
            long base = ip4(q[0]); long size = 1L << (32 - len);
            ex[i][0] = base; ex[i][1] = base + size - 1;
        }
        List<String[]> out = new ArrayList<>();
        split(0, 0, ex, out);
        return out;
    }
    private static void split(long base, int len, long[][] ex, List<String[]> out) {
        long end = base + (1L << (32 - len)) - 1;
        boolean overlap = false;
        for (long[] e : ex) {
            if (e[0] <= base && end <= e[1]) return;         // کامل داخل یک رنج محلی
            if (e[0] <= end && base <= e[1]) overlap = true;
        }
        if (!overlap) { out.add(new String[]{ip4s(base), String.valueOf(len)}); return; }
        split(base, len + 1, ex, out);
        split(base + (1L << (32 - len - 1)), len + 1, ex, out);
    }

    private ParcelFileDescriptor buildTun() throws Exception {
        Builder b = new Builder();
        b.setSession("VPN Scan");
        b.setMtu(mtu);
        b.addAddress("10.10.14.1", 30);
        if (lan) for (String[] r : complement(LAN4)) b.addRoute(r[0], Integer.parseInt(r[1]));
        else b.addRoute("0.0.0.0", 0);
        // IPv6 هم وارد VPN شود؛ وگرنه روی اینترنت‌های IPv6 دار (مثل همراه اول) بعضی برنامه‌ها بیرون از VPN می‌روند و فیلتر می‌خورند
        try { b.addAddress("fc00::10:10:14:1", 126); b.addRoute(lan ? "2000::" : "::", lan ? 3 : 0); } catch (Exception ignored) { }
        b.addDnsServer("1.1.1.1");
        b.addDnsServer("8.8.8.8");
        // تقسیم برنامه‌ها: فقط انتخابی‌ها / همه به‌جز انتخابی‌ها؛ خود برنامه همیشه بیرون
        int allowed = 0;
        if ("only".equals(appMode)) {
            for (String p : apps) { try { b.addAllowedApplication(p); allowed++; } catch (Exception ignored) { } }
        }
        if (allowed == 0) {
            try { b.addDisallowedApplication(getPackageName()); } catch (Exception ignored) { }
            if ("except".equals(appMode)) for (String p : apps) { try { b.addDisallowedApplication(p); } catch (Exception ignored) { } }
        }
        if (Build.VERSION.SDK_INT >= 29) b.setMetered(false);
        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        b.setConfigureIntent(PendingIntent.getActivity(this, 2, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
        ParcelFileDescriptor p = b.establish();
        if (p == null) throw new Exception(tr("اجازهٔ VPN گرفته شد", "VPN permission was revoked"));
        return p;
    }

    /** هسته را برای یک سرور اجرا می‌کند (TUN همان قبلی می‌ماند) */
    private void runCore(Cand c) throws Exception {
        stopCoreOnly();
        stopHelper();
        String cfg = c.cfg;
        httpPort = freePort();
        cfg = cfg.replace("\"__RSHTTP__\"", String.valueOf(httpPort));
        if (cfg.contains("\"__RSIRIP__\"")) cfg = cfg.replace("\"__RSIRIP__\"", irList());
        java.io.File lf = logFile();
        if (lf.length() > 400_000) lf.delete();
        cfg = cfg.replace("\"__RSLOG__\"", JSONObject.quote(lf.getAbsolutePath()));
        if (c.hcfg != null && !c.hcfg.isEmpty()) {
            int port = freePort();
            startHelper(c.hc, c.hcfg, port);
            cfg = cfg.replace("\"__RSPORT__\"", String.valueOf(port));
        }
        libv2ray.Libv2ray.initCoreEnv(getFilesDir().getAbsolutePath(), "");
        ctl = libv2ray.Libv2ray.newCoreController(new libv2ray.CoreCallbackHandler() {
            @Override public long startup() { return 0; }
            @Override public long shutdown() { return 0; }
            @Override public long onEmitStatus(long code, String msg) { return 0; }
        });
        ctl.startLoop(cfg, proxy || tun == null ? 0 : tun.getFd());
        if (!ctl.getIsRunning()) throw new Exception("core did not start");
        core = c.hcfg == null || c.hcfg.isEmpty() ? "x26" : c.hc;
        name = c.name; key = c.k;
    }

    private void begin(JSONObject req) {
        synchronized (lock) {
            readOpts(req.optJSONObject("opts"));
            cands.clear();
            cands.add(Cand.of(req));
            JSONArray alts = req.optJSONObject("opts") != null ? req.optJSONObject("opts").optJSONArray("alts") : null;
            if (alts != null) for (int i = 0; i < alts.length() && cands.size() < 8; i++) {
                JSONObject a = alts.optJSONObject(i); if (a == null) continue;
                Cand x = Cand.of(a);
                if (!x.cfg.isEmpty() && !x.k.equals(cands.get(0).k)) cands.add(x);
            }
            switches = 0; pingN = 0; pingSum = 0; pingFail = 0; lastPing = 0; killHold = false;
            rxTotal = 0; txTotal = 0; rxRate = 0; txRate = 0;
            proxyOn = proxy; proxyShare = proxy && share;
            ParcelFileDescriptor old = tun;
            String why = "";
            try {
                if (proxy) { tun = null; }
                else tun = buildTun();          // جایگزین TUN قبلی می‌شود؛ ترافیک بیرون نمی‌زند
            } catch (Throwable t) {
                why = msg(t);
                tun = null;
            }
            if (old != null && old != tun) { stopCoreOnly(); stopHelper(); try { old.close(); } catch (Exception ignored) { } }
            if (!proxy && tun == null) { fail(why, false); return; }
            synchronized (helperLog) { helperLog.setLength(0); }
            boolean ok = false;
            for (int i = 0; i < cands.size() && !stopping; i++) {
                Cand c = cands.get(i);
                name = c.name;
                if (i > 0) { set("connecting", ""); showNotification(tr("امتحان سرور بعدی… ", "Trying next server… ") + c.name); }
                try {
                    runCore(c);
                    long d = delay();
                    if (d <= 0 && cands.size() > 1 && i + 1 < cands.size()) { hlog("\n[" + c.name + "] no response\n"); continue; }
                    lastPing = d > 0 ? d : -1;
                    if (d > 0) { pingN = 1; pingSum = d; } else pingFail++;
                    ci = i; ok = true;
                    if (i > 0) switches++;
                    break;
                } catch (Throwable t) {
                    why = msg(t);
                    hlog("\n[" + c.name + "] " + why + "\n");
                }
            }
            if (stopping) return;
            if (!ok) { fail(why, false); return; }
            since = System.currentTimeMillis();
            set("on", "");
            showNotification(onText());
            startLoops();
        }
    }

    private static String msg(Throwable t) { return String.valueOf(t.getMessage() != null ? t.getMessage() : t); }

    /** هیچ سروری وصل نشد: یا قطع کامل، یا (با قطع اضطراری وسط اتصال) TUN بسته‌شده باز می‌ماند */
    private void fail(String why, boolean midSession) {
        stopCoreOnly();
        stopHelper();
        if (midSession && kill && tun != null && !proxy) {
            killHold = true;
            set("error", tr("🔒 قطع اضطراری: اینترنت بسته شد تا اتصال برگردد. ", "🔒 Kill switch: internet blocked until the tunnel is back. ") + why);
            showNotification(tr("🔒 اینترنت بسته است (قطع اضطراری) · در حال تلاش برای اتصال", "🔒 Internet blocked (kill switch) · retrying"));
            return;
        }
        persistUsage();
        if (tun != null) { try { tun.close(); } catch (Exception ignored) { } tun = null; }
        since = 0;
        set("error", why);
        stopForeground(STOP_FOREGROUND_REMOVE);
        fgStarted = false;
        stopSelf();
    }

    /** سرور فعلی جواب نمی‌دهد: سرورهای جایگزین به نوبت (اول همین سرور اگر شبکه عوض شده) */
    private boolean failover(boolean sameFirst) {
        synchronized (lock) {
            if (stopping || cands.isEmpty()) return false;
            int n = cands.size();
            String why = "";
            for (int t = 0; t < n && !stopping; t++) {
                int idx = sameFirst ? (ci + t) % n : (ci + 1 + t) % n;
                Cand c = cands.get(idx);
                name = c.name;
                set("connecting", "");
                showNotification(tr("اتصال دوباره… ", "Reconnecting… ") + c.name);
                try {
                    runCore(c);
                    long d = delay();
                    if (d <= 0) { hlog("\n[" + c.name + "] no response\n"); continue; }
                    if (idx != ci) switches++;
                    ci = idx; lastPing = d; pingN++; pingSum += d; killHold = false;
                    if (since == 0) since = System.currentTimeMillis();
                    set("on", "");
                    showNotification(onText());
                    return true;
                } catch (Throwable th) { why = msg(th); hlog("\n[" + c.name + "] " + why + "\n"); }
            }
            if (stopping) return false;
            fail(why.isEmpty() ? tr("هیچ‌کدام از سرورها جواب نداد", "None of the servers responded") : why, true);
            return false;
        }
    }

    private void startLoops() {
        if (supervisor == null || !supervisor.isAlive()) {
            supervisor = new Thread(this::superviseLoop, "rs-vpn-health");
            supervisor.setDaemon(true); supervisor.start();
        }
        if (ticker == null || !ticker.isAlive()) {
            ticker = new Thread(this::trafficLoop, "rs-vpn-traffic");
            ticker.setDaemon(true); ticker.start();
        }
        registerNet();
    }

    // ---------- اتصال پایدار: هر ۶۰ ثانیه چک؛ دو بار پشت هم بی‌جواب → سرور بعدی ----------
    private void superviseLoop() {
        int fails = 0;
        while (!stopping && self == this) {
            long wait = "on".equals(state) ? (fails > 0 ? 5000 : 60000) : 15000;
            synchronized (wake) {
                if (!helperDied && !netEvent) { try { wake.wait(wait); } catch (InterruptedException e) { return; } }
            }
            if (stopping) break;
            if (helperDied) {
                helperDied = false;
                if (health || kill) { failover(false); fails = 0; }
                else { synchronized (lock) { fail(tr("هستهٔ ", "Core ") + core + tr(" بسته شد", " stopped"), false); } }
                continue;
            }
            if (netEvent) {
                netEvent = false;
                try { Thread.sleep(3000); } catch (InterruptedException e) { return; }
                if (stopping) break;
                if ("on".equals(state)) {
                    long d = delay();
                    if (d > 0) { lastPing = d; fails = 0; emit(); continue; }
                    if (health) { failover(true); fails = 0; continue; }
                } else if ("error".equals(state) && killHold) { failover(true); continue; }
            }
            if ("on".equals(state)) {
                long d = delay();
                if (d > 0) { fails = 0; lastPing = d; pingN++; pingSum += d; emit(); continue; }
                fails++; pingFail++; lastPing = -1; emit();
                if (health && fails >= 2) { fails = 0; failover(false); }
            } else if ("error".equals(state) && killHold) {
                failover(true);
            }
        }
    }

    private void registerNet() {
        if (netCb != null) return;
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            netCb = new ConnectivityManager.NetworkCallback() {
                Network last;
                @Override public void onAvailable(Network n) {
                    if (last != null && !last.equals(n)) { netEvent = true; synchronized (wake) { wake.notifyAll(); } }
                    last = n;
                }
                @Override public void onLost(Network n) { if (n.equals(last)) last = null; netEvent = true; }
            };
            cm.registerDefaultNetworkCallback(netCb);
        } catch (Throwable t) { netCb = null; }
    }
    private void unregisterNet() {
        if (netCb == null) return;
        try { ((ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE)).unregisterNetworkCallback(netCb); } catch (Throwable ignored) { }
        netCb = null;
    }

    // ---------- سرعت و حجم مصرف ----------
    private long dayRx = 0, dayTx = 0, lastPersist = 0;
    private void trafficLoop() {
        long prev = System.currentTimeMillis();
        while (!stopping && self == this) {
            try { Thread.sleep(2000); } catch (InterruptedException e) { break; }
            libv2ray.CoreController c = ctl;
            long now = System.currentTimeMillis();
            long up = 0, down = 0;
            if (c != null) {
                try {
                    String s = c.queryAllOutboundTrafficStats();
                    if (s != null) for (String part : s.split(";")) {
                        String[] f = part.split(",");
                        if (f.length != 3) continue;
                        // ترافیک مستقیم (سایت‌های ایرانی، شبکهٔ محلی) و DNS جزو مصرف سرور حساب نمی‌شود
                        if (f[0].equals("direct") || f[0].equals("block") || f[0].equals("dns-out")) continue;
                        long v = Long.parseLong(f[2].trim());
                        if ("uplink".equals(f[1])) up += v; else if ("downlink".equals(f[1])) down += v;
                    }
                } catch (Throwable ignored) { }
            }
            double sec = Math.max(0.5, (now - prev) / 1000.0); prev = now;
            rxRate = (long) (down / sec); txRate = (long) (up / sec);
            rxTotal += down; txTotal += up; dayRx += down; dayTx += up;
            if (now - lastPersist > 30000) persistUsage();
            if ("on".equals(state)) { showNotification(onText()); emit(); }
        }
        persistUsage();
    }

    static String day(long t) {
        java.util.Calendar c = java.util.Calendar.getInstance(); c.setTimeInMillis(t);
        return String.format(java.util.Locale.US, "%04d-%02d-%02d", c.get(java.util.Calendar.YEAR), c.get(java.util.Calendar.MONTH) + 1, c.get(java.util.Calendar.DAY_OF_MONTH));
    }

    private synchronized void persistUsage() {
        lastPersist = System.currentTimeMillis();
        long rx = dayRx, tx = dayTx; dayRx = 0; dayTx = 0;
        if (rx == 0 && tx == 0) return;
        SharedPreferences p = getSharedPreferences(USAGE, MODE_PRIVATE);
        String k = "d" + day(lastPersist);
        String[] v = p.getString(k, "0,0").split(",");
        long t0 = 0, r0 = 0;
        try { t0 = Long.parseLong(v[0]); r0 = Long.parseLong(v[1]); } catch (Exception ignored) { }
        p.edit().putString(k, (t0 + tx) + "," + (r0 + rx)).apply();
        checkLimit(p);
    }

    /** کل مصرف این ماه از تاریخچه */
    static long monthBytes(SharedPreferences p) {
        String m = "d" + day(System.currentTimeMillis()).substring(0, 7);
        long s = 0;
        for (java.util.Map.Entry<String, ?> e : p.getAll().entrySet()) {
            if (!e.getKey().startsWith(m)) continue;
            try { String[] v = String.valueOf(e.getValue()).split(","); s += Long.parseLong(v[0]) + Long.parseLong(v[1]); } catch (Exception ignored) { }
        }
        return s;
    }

    private void checkLimit(SharedPreferences p) {
        if (limitMb <= 0) return;
        String wk = "warned" + day(System.currentTimeMillis()).substring(0, 7);
        if (p.getBoolean(wk, false)) return;
        long used = monthBytes(p);
        if (used < limitMb * 1024L * 1024L) return;
        p.edit().putBoolean(wk, true).apply();
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm.getNotificationChannel(CH2) == null)
                nm.createNotificationChannel(new NotificationChannel(CH2, tr("هشدار مصرف", "Usage alert"), NotificationManager.IMPORTANCE_DEFAULT));
            Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
            PendingIntent pi = PendingIntent.getActivity(this, 5, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            nm.notify(NID_ALERT, new Notification.Builder(this, CH2)
                .setSmallIcon(android.R.drawable.stat_sys_warning)
                .setContentTitle(tr("سقف مصرف ماهانه رسید", "Monthly data limit reached"))
                .setContentText(tr("مصرف این ماه از ", "This month's usage passed ") + fmtBytes(limitMb * 1024L * 1024L) + tr(" گذشت", ""))
                .setContentIntent(pi).setAutoCancel(true).build());
        } catch (Throwable ignored) { }
    }

    static String fmtBytes(long b) {
        if (b < 1024) return b + " B";
        if (b < 1024 * 1024) return String.format(java.util.Locale.US, "%.0f KB", b / 1024.0);
        if (b < 1024L * 1024 * 1024) return String.format(java.util.Locale.US, "%.1f MB", b / 1048576.0);
        return String.format(java.util.Locale.US, "%.2f GB", b / 1073741824.0);
    }
    private static String fmtRate(long b) { return fmtBytes(b) + "/s"; }

    private String onText() {
        String head = proxy ? tr("پروکسی روشن است", "Proxy on") + " · " + (share ? "0.0.0.0" : "127.0.0.1") + ":" + proxyPort
                            : tr("وصل است", "Connected");
        return head + (name.isEmpty() ? "" : " · " + name)
            + "\n↓ " + fmtRate(rxRate) + "  ↑ " + fmtRate(txRate) + "  · " + fmtBytes(rxTotal + txTotal);
    }

    private void stopCoreOnly() {
        try { if (ctl != null) ctl.stopLoop(); } catch (Throwable ignored) { }
        ctl = null;
    }

    void stopVpn() {
        stopping = true;
        synchronized (wake) { wake.notifyAll(); }
        synchronized (lock) {
            unregisterNet();
            persistUsage();
            stopCoreOnly();
            stopHelper();
            if (tun != null) { try { tun.close(); } catch (Exception ignored) { } tun = null; }
            since = 0; killHold = false; rxRate = 0; txRate = 0; proxyOn = false;
            if (!"error".equals(state)) set("off", "");
            fgStarted = false;
        }
    }

    /** تأخیر واقعی از داخل اتصال فعلی (ms، یا -1) */
    long delay() {
        libv2ray.CoreController c = ctl;
        if (c == null) return -1;
        try { long v = c.measureDelay("https://www.gstatic.com/generate_204"); return v > 0 ? v : -1; } catch (Throwable t) { return -1; }
    }

    private Object viaVpn(String url, int timeoutMs, long maxBytes) {
        java.net.HttpURLConnection c = null;
        try {
            java.net.Proxy px = new java.net.Proxy(java.net.Proxy.Type.HTTP, new java.net.InetSocketAddress("127.0.0.1", httpPort));
            c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection(px);
            c.setConnectTimeout(timeoutMs); c.setReadTimeout(timeoutMs); c.setUseCaches(false);
            c.setRequestProperty("User-Agent", "Mozilla/5.0");
            int code = c.getResponseCode();
            if (code < 200 || code >= 400) return null;
            java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
            long t0 = System.nanoTime(), n = 0;
            try (java.io.InputStream in = c.getInputStream()) {
                byte[] b = new byte[32768]; int k;
                while ((k = in.read(b)) > 0) {
                    n += k; if (maxBytes <= 0) out.write(b, 0, k);
                    if (maxBytes > 0 && (n >= maxBytes || System.nanoTime() - t0 > 8_000_000_000L)) break;
                }
            }
            if (maxBytes > 0) { double sec = (System.nanoTime() - t0) / 1e9; return sec > 0 ? n * 8 / sec / 1e6 : 0.0; }
            return out.toString("UTF-8");
        } catch (Exception e) { return null; }
        finally { if (c != null) c.disconnect(); }
    }

    /** پینگ، IP و موقعیت خروجی، و سرعت دانلود — همه از داخل همین اتصال VPN */
    String info() {
        JSONObject o = new JSONObject();
        try {
            o.put("core", core); o.put("name", name);
            o.put("ping", delay());
            if (httpPort > 0) {
                Object j = viaVpn("https://ipwho.is/", 8000, 0);
                if (j instanceof String) {
                    try {
                        JSONObject w = new JSONObject((String) j);
                        o.put("ip", w.optString("ip")); o.put("country", w.optString("country")); o.put("cc", w.optString("country_code"));
                        o.put("city", w.optString("city"));
                        JSONObject cn = w.optJSONObject("connection");
                        if (cn != null) o.put("isp", cn.optString("isp", cn.optString("org")));
                    } catch (Exception ignored) { }
                }
                if (o.optString("ip").isEmpty()) {
                    Object t = viaVpn("https://www.cloudflare.com/cdn-cgi/trace", 8000, 0);
                    if (t instanceof String) for (String line : ((String) t).split("\n")) {
                        if (line.startsWith("ip=")) o.put("ip", line.substring(3));
                        if (line.startsWith("loc=")) o.put("cc", line.substring(4));
                    }
                }
                Object sp = viaVpn("https://speed.cloudflare.com/__down?bytes=8000000", 10000, 8_000_000L);
                if (sp instanceof Double) o.put("mbps", Math.round((Double) sp * 10) / 10.0);
            }
        } catch (Exception ignored) { }
        return o.toString();
    }

    /** لاگ هسته‌ها (آخرین بخش) برای «گزارش‌های سیستم» */
    static String logs(Context ctx) {
        StringBuilder sb = new StringBuilder();
        java.io.File f = new java.io.File(ctx.getFilesDir(), "core.log");
        if (f.exists()) {
            try (java.io.RandomAccessFile r = new java.io.RandomAccessFile(f, "r")) {
                long len = r.length(), from = Math.max(0, len - 16000);
                r.seek(from);
                byte[] b = new byte[(int) (len - from)]; r.readFully(b);
                String s = new String(b, StandardCharsets.UTF_8);
                if (from > 0) { int nl = s.indexOf('\n'); if (nl >= 0) s = s.substring(nl + 1); }
                sb.append(s);
            } catch (Exception ignored) { }
        }
        synchronized (helperLog) { if (helperLog.length() > 0) sb.append(helperLog); }
        return sb.toString();
    }
    static void clearLogs(Context ctx) {
        new java.io.File(ctx.getFilesDir(), "core.log").delete();
        synchronized (helperLog) { helperLog.setLength(0); }
    }

    /** تاریخچهٔ مصرف: {"2026-10-29":[up,down], ...} */
    static String usageJson(Context ctx) {
        try {
            SharedPreferences p = ctx.getSharedPreferences(USAGE, MODE_PRIVATE);
            JSONObject o = new JSONObject();
            for (java.util.Map.Entry<String, ?> e : p.getAll().entrySet()) {
                if (!e.getKey().startsWith("d")) continue;
                String[] v = String.valueOf(e.getValue()).split(",");
                o.put(e.getKey().substring(1), new JSONArray().put(Long.parseLong(v[0])).put(Long.parseLong(v[1])));
            }
            return o.toString();
        } catch (Exception e) { return "{}"; }
    }

    private void showNotification(String text) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null && nm.getNotificationChannel(CH) == null)
            nm.createNotificationChannel(new NotificationChannel(CH, "VPN", NotificationManager.IMPORTANCE_LOW));
        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 3, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent stop = new Intent(this, RsVpnService.class).setAction(ACT_STOP);
        PendingIntent ps = PendingIntent.getService(this, 4, stop, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        String first = text.contains("\n") ? text.substring(0, text.indexOf('\n')) : text;
        Notification n = new Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("VPN Scan")
            .setContentText(first)
            .setStyle(new Notification.BigTextStyle().bigText(text))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(pi)
            .addAction(new Notification.Action.Builder(null, tr("قطع", "Disconnect"), ps).build())
            .build();
        if (!fgStarted) {
            if (Build.VERSION.SDK_INT >= 34) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            else startForeground(NID, n);
            fgStarted = true;
        } else if (nm != null) nm.notify(NID, n);
    }

    @Override
    public void onRevoke() {
        stopVpn();
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
        super.onRevoke();
    }

    @Override
    public void onDestroy() {
        stopVpn();
        self = null;
        super.onDestroy();
    }
}
