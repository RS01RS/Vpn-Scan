package com.rs.v2ray;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.net.VpnService;
import android.os.Build;
import android.os.ParcelFileDescriptor;

import org.json.JSONObject;

/**
 * VPN داخل خود برنامه: هستهٔ Xray (libv2ray، همان هستهٔ v2rayNG) با ورودی TUN.
 * ترافیک خود VPN Scan از VPN رد نمی‌شود تا اسکن و تست‌ها مستقیم بمانند.
 */
public class RsVpnService extends VpnService {

    static final String ACT_START = "com.rs.v2ray.VPN_START";
    static final String ACT_STOP = "com.rs.v2ray.VPN_STOP";
    private static final String CH = "rs_vpn";
    private static final int NID = 9;

    // وضعیت برای صفحه: off | connecting | on | error
    static volatile String state = "off";
    static volatile String name = "";
    static volatile String err = "";
    static volatile long since = 0;
    static volatile Runnable listener;
    static volatile RsVpnService self;
    static volatile boolean english = false;
    private static String tr(String fa, String en) { return english ? en : fa; }

    private ParcelFileDescriptor tun;
    private libv2ray.CoreController ctl;
    // هستهٔ کمکی (Xray 25 برای NPV یا sing-box برای Hiddify) که پشت TUN با SOCKS محلی کار می‌کند
    private Process helper;
    private java.io.File helperConf;
    static volatile String core = "x26";
    private final Object lock = new Object();

    static String stateJson() {
        try {
            JSONObject o = new JSONObject();
            o.put("state", state); o.put("name", name); o.put("err", err); o.put("since", since); o.put("core", core);
            return o.toString();
        } catch (Exception e) { return "{\"state\":\"off\"}"; }
    }

    private static void emit() { Runnable l = listener; if (l != null) l.run(); }

    private static void set(String st, String e) { state = st; err = e == null ? "" : e; emit(); }

    @Override
    public void onCreate() { super.onCreate(); self = this; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String act = intent != null ? intent.getAction() : null;
        if (ACT_STOP.equals(act)) {
            new Thread(() -> { stopVpn(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); }).start();
            return START_NOT_STICKY;
        }
        if (ACT_START.equals(act)) {
            final String cfg = intent.getStringExtra("cfg");
            final String nm = intent.getStringExtra("name");
            final String hc = intent.getStringExtra("helperCore");
            final String hcfg = intent.getStringExtra("helperCfg");
            core = hc == null || hc.isEmpty() ? "x26" : hc;
            name = nm == null ? "" : nm;
            set("connecting", "");
            showNotification(tr("در حال اتصال…", "Connecting…"));
            new Thread(() -> startVpn(cfg, hc, hcfg)).start();
        }
        return START_NOT_STICKY;
    }

    private static int freePort() {
        try (java.net.ServerSocket s = new java.net.ServerSocket(0, 1, java.net.InetAddress.getByName("127.0.0.1"))) { return s.getLocalPort(); }
        catch (Exception e) { return 21000 + (int) (Math.random() * 20000); }
    }

    /** هستهٔ کمکی را با ورودی SOCKS روی پورت داده‌شده بالا می‌آورد؛ اگر نشد، Exception با خروجی هسته */
    private void startHelper(String hc, String hcfg, int port) throws Exception {
        String bin = "x25".equals(hc) ? "libxray25.so" : "libsingbox.so";
        java.io.File f = new java.io.File(getApplicationInfo().nativeLibraryDir, bin);
        if (!f.exists()) throw new Exception(tr("این هسته روی این گوشی نیست (فقط گوشی‌های ۶۴ بیتی)", "this core isn't available on this phone (64-bit only)"));
        helperConf = java.io.File.createTempFile("vpn_", ".json", getCacheDir());
        try (java.io.FileOutputStream o = new java.io.FileOutputStream(helperConf)) {
            o.write(hcfg.replace("\"__RSPORT__\"", String.valueOf(port)).getBytes(java.nio.charset.StandardCharsets.UTF_8));
        }
        ProcessBuilder pb = new ProcessBuilder(f.getAbsolutePath(), "run", "-c", helperConf.getAbsolutePath());
        pb.directory(getCacheDir()); pb.redirectErrorStream(true);
        pb.environment().put("XRAY_LOCATION_ASSET", getCacheDir().getAbsolutePath());
        pb.environment().put("HOME", getCacheDir().getAbsolutePath());
        helper = pb.start();
        final Process pr = helper; final StringBuilder out = new StringBuilder();
        Thread rd = new Thread(() -> {
            try (java.io.InputStream in = pr.getInputStream()) {
                byte[] b = new byte[2048]; int n;
                while ((n = in.read(b)) > 0) synchronized (out) { if (out.length() < 4000) out.append(new String(b, 0, n, java.nio.charset.StandardCharsets.UTF_8)); }
            } catch (Exception ignored) { }
            // اگر هستهٔ کمکی وسط اتصال بسته شد، VPN هم قطع شود
            if ("on".equals(state) && helper == pr) {
                stopVpn(); set("error", tr("هستهٔ ", "Core ") + core + tr(" بسته شد", " stopped"));
                stopForeground(STOP_FOREGROUND_REMOVE); stopSelf();
            }
        });
        rd.setDaemon(true); rd.start();
        long until = System.currentTimeMillis() + 6000;
        while (System.currentTimeMillis() < until) {
            if (!helper.isAlive()) break;
            try (java.net.Socket so = new java.net.Socket()) { so.connect(new java.net.InetSocketAddress("127.0.0.1", port), 200); return; }
            catch (Exception e) { Thread.sleep(80); }
        }
        Thread.sleep(150);
        String o; synchronized (out) { o = out.toString().replaceAll("\u001B\\[[0-9;]*m", "").trim(); }
        throw new Exception(o.isEmpty() ? "helper core didn't start" : o.substring(Math.max(0, o.length() - 240)));
    }

    private void stopHelper() {
        Process p = helper; helper = null;
        if (p != null) p.destroyForcibly();
        if (helperConf != null) { helperConf.delete(); helperConf = null; }
    }

    private void startVpn(String cfg, String hc, String hcfg) {
        synchronized (lock) {
            stopCoreOnly();
            stopHelper();
            try {
                if (hcfg != null && !hcfg.isEmpty()) {
                    int port = freePort();
                    startHelper(hc, hcfg, port);
                    cfg = cfg.replace("\"__RSPORT__\"", String.valueOf(port));
                }
                libv2ray.Libv2ray.initCoreEnv(getFilesDir().getAbsolutePath(), "");
                Builder b = new Builder();
                b.setSession("VPN Scan");
                b.setMtu(1500);
                b.addAddress("10.10.14.1", 30);
                b.addRoute("0.0.0.0", 0);
                b.addDnsServer("1.1.1.1");
                b.addDnsServer("8.8.8.8");
                try { b.addDisallowedApplication(getPackageName()); } catch (Exception ignored) { }
                if (Build.VERSION.SDK_INT >= 29) b.setMetered(false);
                Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                b.setConfigureIntent(PendingIntent.getActivity(this, 2, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
                if (tun != null) { try { tun.close(); } catch (Exception ignored) { } tun = null; }
                tun = b.establish();
                if (tun == null) throw new Exception("VPN permission was revoked");
                ctl = libv2ray.Libv2ray.newCoreController(new libv2ray.CoreCallbackHandler() {
                    @Override public long startup() { return 0; }
                    @Override public long shutdown() { return 0; }
                    @Override public long onEmitStatus(long code, String msg) { return 0; }
                });
                ctl.startLoop(cfg, tun.getFd());
                if (!ctl.getIsRunning()) throw new Exception("core did not start");
                since = System.currentTimeMillis();
                set("on", "");
                showNotification(tr("وصل است", "Connected") + (name.isEmpty() ? "" : " · " + name));
            } catch (Throwable t) {
                stopCoreOnly();
                stopHelper();
                if (tun != null) { try { tun.close(); } catch (Exception ignored) { } tun = null; }
                set("error", String.valueOf(t.getMessage() != null ? t.getMessage() : t));
                stopForeground(STOP_FOREGROUND_REMOVE);
                stopSelf();
            }
        }
    }

    private void stopCoreOnly() {
        try { if (ctl != null) ctl.stopLoop(); } catch (Throwable ignored) { }
        ctl = null;
    }

    void stopVpn() {
        synchronized (lock) {
            stopCoreOnly();
            stopHelper();
            if (tun != null) { try { tun.close(); } catch (Exception ignored) { } tun = null; }
            since = 0;
            if (!"error".equals(state)) set("off", "");
        }
    }

    /** تأخیر واقعی از داخل اتصال فعلی (ms، یا -1) */
    long delay() {
        libv2ray.CoreController c = ctl;
        if (c == null) return -1;
        try { long v = c.measureDelay("https://www.gstatic.com/generate_204"); return v > 0 ? v : -1; } catch (Throwable t) { return -1; }
    }

    private void showNotification(String text) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null && nm.getNotificationChannel(CH) == null)
            nm.createNotificationChannel(new NotificationChannel(CH, "VPN", NotificationManager.IMPORTANCE_LOW));
        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 3, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent stop = new Intent(this, RsVpnService.class).setAction(ACT_STOP);
        PendingIntent ps = PendingIntent.getService(this, 4, stop, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("VPN Scan")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(pi)
            .addAction(new Notification.Action.Builder(null, tr("قطع", "Disconnect"), ps).build())
            .build();
        if (Build.VERSION.SDK_INT >= 34) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(NID, n);
    }

    @Override
    public void onRevoke() {
        stopVpn();
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
        super.onRevoke();
    }

    @Override
    public void onDestroy() {
        stopVpn();
        self = null;
        super.onDestroy();
    }
}
